let display = document.getElementById("display");
let history = document.getElementById("history");
let lastAnswer = "";

function append(value) {
  if (display.innerText === "0" || display.innerText === "Error") {
    display.innerText = "";
  }
  if (value === "pi") {
    display.innerText += Math.PI;
  } else if (value === "e") {
    display.innerText += Math.E;
  } else if (value === "ANS") {
    display.innerText += lastAnswer;
  } else {
    display.innerText += value;
  }
}

function clearDisplay() {
  display.innerText = "0";
}

function backspace() {
  let current = display.innerText;
  if (current.length > 1) {
    display.innerText = current.slice(0, -1);
  } else {
    display.innerText = "0";
  }
}

function calculate() {
  try {
    let expr = display.innerText
      .replace(/π|pi/g, Math.PI)
      .replace(/e/g, Math.E)
      .replace(/ANS/g, lastAnswer)
      .replace(/sqrt\(/g, "Math.sqrt(")
      .replace(/sin\(/g, "Math.sin(")
      .replace(/cos\(/g, "Math.cos(")
      .replace(/tan\(/g, "Math.tan(")
      .replace(/log\(/g, "Math.log10(")
      .replace(/ln\(/g, "Math.log(")
      .replace(/\^/g, "**");

    let result = eval(expr);
    if (typeof result === "number" && isFinite(result)) {
      lastAnswer = result;
      history.innerText += `${display.innerText} = ${result}\n`;
      display.innerText = result;
    } else {
      display.innerText = "Error";
    }
  } catch {
    display.innerText = "Error";
  }
}